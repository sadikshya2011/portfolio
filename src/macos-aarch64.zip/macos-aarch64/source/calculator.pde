// Sadikshya Kuikel | 09/25/25 | calculator
Button [] buttons = new Button[13];
Button[] numButtons = new Button[10];
float l, r, result;
String dVal;
char op;
boolean left;
void setup() {
  size(320, 380);
  l = 0.0;
  r = 0.0;
  result = 0.0;
  dVal = "0.0";
  op = ' ';
  left = true;
  buttons[0] = new Button (40, 105, 40, 40, 'C', #F2A1BB, #D68AA2);
  numButtons[0] = new Button (70, 340, 100, 40, '0', #FFDBE6, #E8BECB);
  buttons[1] = new Button (100, 105, 40, 40, '±', #F2A1BB, #D68AA2);
  buttons[2] = new Button (160, 105, 40, 40, '^', #F2A1BB, #D68AA2);
  buttons[3] = new Button (220, 105, 40, 40, '²', #F2A1BB, #D68AA2);
  buttons[4] = new Button (280, 105, 40, 40, '√', #F2A1BB, #D68AA2);
  numButtons[7] = new Button (40, 165, 40, 40, '7', #FFDBE6, #E8BECB);
  numButtons[8] = new Button (100, 165, 40, 40, '8', #FFDBE6, #E8BECB);
  numButtons[9] = new Button (160, 165, 40, 40, '9', #FFDBE6, #E8BECB);
  buttons[5] = new Button (220, 165, 40, 40, '÷', #F2A1BB, #D68AA2);
  buttons[6] = new Button (280, 165, 40, 40, 's', #F2A1BB, #D68AA2);
  numButtons[4] = new Button (40, 225, 40, 40, '4', #FFDBE6, #E8BECB);
  numButtons[5] = new Button (100, 225, 40, 40, '5', #FFDBE6, #E8BECB);
  numButtons[6] = new Button (160, 225, 40, 40, '6', #FFDBE6, #E8BECB);
  buttons[7] = new Button (220, 225, 40, 40, 'x', #F2A1BB, #D68AA2);
  buttons[8] = new Button (280, 225, 40, 40, 't', #F2A1BB, #D68AA2);
  numButtons[1] = new Button (40, 285, 40, 40, '1', #FFDBE6, #E8BECB);
  numButtons[2] = new Button (100, 285, 40, 40, '2', #FFDBE6, #E8BECB);
  numButtons[3] = new Button (160, 285, 40, 40, '3', #FFDBE6, #E8BECB);
  buttons[9] = new Button (220, 285, 40, 40, '+', #F2A1BB, #D68AA2);
  buttons[10] = new Button (280, 315, 40, 100, '=', #F2A1BB, #D68AA2);
  buttons[11] = new Button (160, 340, 40, 40, '.', #FFDBE6, #E8BECB);
  buttons[12] = new Button (220, 340, 40, 40, '-', #F2A1BB, #D68AA2);
}

void draw () {
  background(#FFF2F6);
  for (int i = 0; i<buttons.length; i++) {
    buttons[i].display();
    buttons[i].hover(mouseX, mouseY);
  }
  for (int i = 0; i<numButtons.length; i++) {
    numButtons[i].display();
    numButtons[i].hover(mouseX, mouseY);
  }
  updateDisplay();
}

void mousePressed() {
  for (int i = 0; i<buttons.length; i++) {
    if (buttons[i].over && buttons[i].val == '+') {
      dVal = "0.0";
      left = false;
      op = '+';
    } else if (buttons[i].over && buttons[i].val == '=') {
      performCalculation();
    } else if (buttons[i].over && buttons[i].val == '²') {
      if (left) {
        l = sq(l);
        dVal = str(l);
      } else {
        r = sq(r);
        dVal = str(r);
      }
    } else if (buttons[i].over && buttons[i].val == '.') {
      if (dVal.contains (".") == false ) {
        dVal += ".";
      }
    } else if (buttons[i].over && buttons[i].val == '±') {
      if (left) {
        l = l * -1;
        dVal = str(l);
      } else {
        r = r * -1;
      }
    } else if (buttons[i].over && buttons[i].val == 'C') {


      l = 0.0;
      r = 0.0;
      result = 0.0;
      dVal = "0.0";
      op = ' ';
      left = true;
    } else if (buttons[i].over && buttons[i].val == '-') {
      left = false;
      dVal = "0.0";
      op = '-';
    } else if (buttons[i].over && buttons[i].val == '÷') {
      dVal = "0.0";
      left = false;
      op = '/';
    } else if (buttons[i].over && buttons[i].val == 'x') {
      dVal = "0.0";
      left = false;
      op = '*';
    }
  }


  for (int i = 0; i<numButtons.length; i++) {
    if (dVal.length()<18) {
      if (numButtons[i].over && left == true) {
        if (dVal.equals("0.0")) {
          dVal = str(numButtons[i].val);
          r = float(dVal);
        } else {
          dVal += str(numButtons[i].val);
          r = float (dVal);
        }
      } else if (numButtons[i].over && left == false) {
        if (dVal.equals("0.0")) {
          dVal = str(numButtons[i].val);
          l = float(dVal);
        } else {
          dVal += str(numButtons[i].val);
          l = float (dVal);
        }
      }
    }
  }
  println("l:" + l);
  println("r:"+r);
  println("result:"+result);
  println("left"+left);
  println("op:"+ op);
}

void updateDisplay() {
  rectMode(CORNER);
  fill (#FCF5F7);
  rect(20, 20, 280, 40, 4);
  textAlign(RIGHT);
  fill(#B92F59);
  textSize(30);
  text(dVal, width-25, 50);
}

void performCalculation() {
  if (op == ('+')) {
    result = l + r;
  } else if (op == ('-')) {
    result = l - r;
  } else if (op == ('*')) {
    result = l * r;
  } else if (op == ('/')) {
    result = l / r;
  }
  dVal = str(result);
  l = result;
}
